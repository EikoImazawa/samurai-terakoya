package com.example.nagoyameshi.service;

import java.time.LocalDate;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.nagoyameshi.entity.Reservation;
import com.example.nagoyameshi.entity.Shop;
import com.example.nagoyameshi.entity.User;
import com.example.nagoyameshi.repository.ReservationRepository;
import com.example.nagoyameshi.repository.ShopRepository;
import com.example.nagoyameshi.repository.UserRepository;

@Service
public class ReservationService {
     private final ReservationRepository reservationRepository;  
     private final ShopRepository shopRepository;  
     private final UserRepository userRepository;  
     
     public ReservationService(ReservationRepository reservationRepository, ShopRepository shopRepository, UserRepository userRepository) {
         this.reservationRepository = reservationRepository;  
         this.shopRepository = shopRepository;  
         this.userRepository = userRepository;  
     }    
          
     @Transactional
     public void create(Map<String, String> paymentIntentObject) {
         Reservation reservation = new Reservation();
         Integer shopId = Integer.valueOf(paymentIntentObject.get("shopId"));
         Integer userId = Integer.valueOf(paymentIntentObject.get("userId"));
                 
         Shop shop = shopRepository.getReferenceById(shopId);       
         User user = userRepository.getReferenceById(userId);
         LocalDate reservDate = LocalDate.parse(paymentIntentObject.get("reservDate"));
         Integer numberOfPeople = Integer.valueOf(paymentIntentObject.get("numberOfPeople"));        

         reservation.setShop(shop);
         reservation.setUser(user);
         reservation.setReservDate(reservDate);
         reservation.setNumberOfPeople(numberOfPeople);
         
         reservationRepository.save(reservation);
     }    

}
