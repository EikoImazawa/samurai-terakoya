--categoriesテーブル--
INSERT IGNORE INTO categories (id, name) VALUES (1, '汁物');
INSERT IGNORE INTO categories (id, name) VALUES (2, '地方名物');
INSERT IGNORE INTO categories (id, name) VALUES (2, 'イタリアン');
INSERT IGNORE INTO categories (id, name) VALUES (3, 'ゴハン');
INSERT IGNORE INTO categories (id, name) VALUES (4, '揚げ物');
INSERT IGNORE INTO categories (id, name) VALUES (5, '居酒屋');
INSERT IGNORE INTO categories (id, name) VALUES (6, 'カフェ');
INSERT IGNORE INTO categories (id, name) VALUES (7, '日本食');
INSERT IGNORE INTO categories (id, name) VALUES (8, '麺類');

-- shopsテーブル
INSERT IGNORE INTO shops (id, name, image_name, description, price, price_max, open_time, close_time, postal_code, address, phone_number, rest_day, category_id) VALUES (1, '手羽きん屋', 'meshi_01.jpg', '最寄り駅から徒歩10分。自然豊かで閑静な場所にあります。長期滞在も可能です。', 2000, 6000, '9:00', '20:00', '073-0145', '北海道砂川市西五条南X-XX-XX', '012-345-678' , '土日祝日', 1);
INSERT IGNORE INTO shops (id, name, image_name, description, price, price_max, open_time, close_time, postal_code, address, phone_number, rest_day, category_id) VALUES (2, '味噌煮込みうどんヌ', 'meshi_02.jpg', '最寄り駅から徒歩10分。自然豊かで閑静な場所にあります。長期滞在も可能です。', 1000, 8000, '9:00', '20:00', '073-0145', '北海道砂川市西五条南X-XX-XX', '012-345-678' , '土日祝日', 2);
INSERT IGNORE INTO shops (id, name, image_name, description, price, price_max, open_time, close_time, postal_code, address, phone_number, rest_day, category_id) VALUES (3, 'パスタイトリアン', 'meshi_03.jpg', '最寄り駅から徒歩10分。自然豊かで閑静な場所にあります。長期滞在も可能です。', 500, 3000, '9:00', '20:00', '073-0145', '北海道砂川市西五条南X-XX-XX', '012-345-678' , '土日祝日', 3);
INSERT IGNORE INTO shops (id, name, image_name, description, price, price_max, open_time, close_time, postal_code, address, phone_number, rest_day, category_id) VALUES (4, 'よっ寿司ドンマイ', 'meshi_04.jpg', '最寄り駅から徒歩10分。自然豊かで閑静な場所にあります。長期滞在も可能です。', 3000, 7000, '9:00', '20:00', '073-0145', '北海道砂川市西五条南X-XX-XX', '012-345-678' , '土日祝日', 4);
INSERT IGNORE INTO shops (id, name, image_name, description, price, price_max, open_time, close_time, postal_code, address, phone_number, rest_day, category_id) VALUES (5, 'みっそみそ', 'meshi_05.jpg', '最寄り駅から徒歩10分。自然豊かで閑静な場所にあります。長期滞在も可能です。', 3000, 7000, '9:00', '20:00', '073-0145', '北海道砂川市西五条南X-XX-XX', '012-345-678' , '土日祝日', 5);
INSERT IGNORE INTO shops (id, name, image_name, description, price, price_max, open_time, close_time, postal_code, address, phone_number, rest_day, category_id) VALUES (6, '卵ナポリタン', 'meshi_06.jpg', '最寄り駅から徒歩10分。自然豊かで閑静な場所にあります。長期滞在も可能です。', 3000, 7000, '9:00', '20:00', '073-0145', '北海道砂川市西五条南X-XX-XX', '012-345-678' , '土日祝日', 6);
INSERT IGNORE INTO shops (id, name, image_name, description, price, price_max, open_time, close_time, postal_code, address, phone_number, rest_day, category_id) VALUES (7, '鳥富豪', 'meshi_07.jpg', '最寄り駅から徒歩10分。自然豊かで閑静な場所にあります。長期滞在も可能です。', 5000, 10000, '9:00', '20:00', '073-0145', '北海道砂川市西五条南X-XX-XX', '012-345-678' , '土日祝日', 7);
INSERT IGNORE INTO shops (id, name, image_name, description, price, price_max, open_time, close_time, postal_code, address, phone_number, rest_day, category_id) VALUES (8, 'ココダ珈琲', 'meshi_08.jpg', '最寄り駅から徒歩10分。自然豊かで閑静な場所にあります。長期滞在も可能です。', 500, 2000, '9:00', '20:00', '073-0145', '北海道砂川市西五条南X-XX-XX', '012-345-678' , '土日祝日', 8);

-- rolesテーブル
INSERT IGNORE INTO roles (id, name) VALUES (1, 'ROLE_GENERAL');
INSERT IGNORE INTO roles (id, name) VALUES (2, 'ROLE_ADD_GENERAL');
INSERT IGNORE INTO roles (id, name) VALUES (3, 'ROLE_ADDPULUS_GENERAL');
INSERT IGNORE INTO roles (id, name) VALUES (4, 'ROLE_ADMIN');

-- usersテーブル--
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (1,'侍 太郎','サムライ タロウ','101-0022','東京都千代田区神田練塀町300番地','090-1234-5678','taro.samurai@example.com','password',1,true);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (2,'侍 花子','サムライ ハナコ','101-0022','東京都千代田区神田練塀町300番地','090-1234-5678','hanako.samurai@example.com','password',4,true);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (3,'侍 義勝','サムライ ヨシカツ','638-0644','奈良県五條市西吉野町湯川X-XX-XX','090-1234-5678','yoshikatsu.samurai@example.com','password',2,false);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (4,'侍 幸美','サムライ サチミ','342-0006','埼玉県吉川市南広島X-XX-XX','090-1234-5678','sachimi.samurai@example.com','password',3,false);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (5,'侍 雅','サムライ ミヤビ','527-0209','滋賀県東近江市佐目町X-XX-XX','090-1234-5678','miyabi.samurai@example.com','password',1,false);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (6,'侍 正保','サムライ マサヤス','989-1203','宮城県柴田郡大河原町旭町X-XX-XX','090-1234-5678','masayasu.samurai@example.com','password',1,false);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (7,'侍 真由美','サムライ マユミ','951-8015','新潟県新潟市松岡町X-XX-XX','090-1234-5678','mayumi.samurai@example.com','password',1,false);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (8,'侍 安民','サムライ ヤスタミ','241-0033','神奈川県横浜市旭区今川町X-XX-XX','090-1234-5678','yasutami.samurai@example.com','password',1,false);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (9,'侍 章緒','サムライ アキオ','739-2103','広島県東広島市高屋町宮領X-XX-XX','090-1234-5678','akio.samurai@example.com','password',1,false);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (10,'侍 祐子','サムライ ユウコ','601-0761','京都府南丹市美山町高野X-XX-XX','090-1234-5678','yuko.samurai@example.com','password',1,false);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (11,'侍 秋美','サムライ アキミ','606-8235','京都府京都市左京区田中西春菜町X-XX-XX','090-1234-5678','akimi.samurai@example.com','password',1,false);
INSERT IGNORE INTO users (id,name,furigana,postal_code,address,phone_number,email,password,role_id,enabled) VALUES (12,'侍 信平','サムライ シンペイ','673-1324','兵庫県加東市新定X-XX-XX','090-1234-5678','shinpei.samurai@example.com','password',1,false);

-- reservationsテーブル--
INSERT IGNORE INTO reservations (id,shop_id,user_id,reserv_date,number_of_people) VALUES (1,1,1,'2023-04-01',2);
INSERT IGNORE INTO reservations (id,shop_id,user_id,reserv_date,number_of_people) VALUES (2,2,1,'2023-04-01',3);
INSERT IGNORE INTO reservations (id,shop_id,user_id,reserv_date,number_of_people) VALUES (3,3,1,'2023-04-01',4);

-- favoritesテーブル
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (1, 1, 1);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (2, 2, 1);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (3, 3, 1);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (4, 4, 1);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (5, 5, 1);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (6, 6, 1);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (7, 7, 1);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (8, 8, 1);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (9, 2, 2);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (10, 2, 13);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (11, 2, 13);
 INSERT IGNORE INTO favorites (id, shop_id, user_id) VALUES (12, 2, 13);

-- companyテーブル--
INSERT IGNORE INTO company (id,name,representative,build_day,postal_code,address,description) VALUES (1,'株式会社NAGOYAMESHI','侍 宗一郎','2000年10月10日','101-0022','東京都千代田区神田練塀町300番地','名古屋のB級グルメのみのグルメの紹介と顧客のタイムリーな評価を行える、快適なサポートをしております。');

-- reviewsテーブル--
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (1,1,4,5,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (2,1,5,5,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (3,1,1,4,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (4,1,2,4,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (5,1,3,4,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (6,2,1,3,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (7,3,1,3,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (8,4,1,3,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (9,5,1,3,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (10,6,1,3,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');
INSERT IGNORE INTO reviews (id,shop_id,user_id,ster,reviews_comment) VALUES (11,1,7,3,'名古屋市における最高の手羽先屋です。トロっとした秘伝のタレとサックサクの衣、ジューシーな鶏肉に食欲がそそられました。');