package com.example.nagoyameshi.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.nagoyameshi.entity.Category;
import com.example.nagoyameshi.entity.Shop;
import com.example.nagoyameshi.repository.ShopRepository;
import com.example.nagoyameshi.service.CategoryService;

 @Controller
public class HomeController {
     private final ShopRepository shopRepository;        
     private final CategoryService categoryService;

     public HomeController(ShopRepository shopRepository, CategoryService categoryService) {
         this.shopRepository = shopRepository;        
         this.categoryService = categoryService;

     }    

     @GetMapping("/")
     public String index(Model model) {
         List<Shop> newShops = shopRepository.findTop10ByOrderByCreatedAtDesc();
         model.addAttribute("newShops", newShops);
         
         List<Category> categoryList = categoryService.getCategory();
         model.addAttribute("categoryList",categoryList);

         return "index";
     }   
}
